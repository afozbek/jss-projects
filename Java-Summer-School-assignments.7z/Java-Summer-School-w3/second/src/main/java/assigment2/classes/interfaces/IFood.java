package assigment2.classes.interfaces;

public interface IFood {
    void prepare();

    void cook();

    void send();
}

