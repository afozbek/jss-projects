package com.assigment1.main;

import com.assigment1.classes.Class3;

public class MainClass {

    public static void main(String[] args) {
        Class3 class3 = new Class3();
        class3.callMethod();
    }
}

