package com.assigment1.classes;

public class Class1 {
    public static void willGenerateException() throws CustomException {
        throw new CustomException();
    }
}


